package com.cel.app.cal;

public class Calculator {
	
	private int a,b;
	
	 protected Calculator(int a,int b)
	{
		this.a=a;
		this.b=b;
	}

	protected int getA() {
		return a;
	}

	protected void setA(int a) {
		this.a = a;
	}

	protected int getB() {
		return b;
	}

	protected void setB(int b) {
		this.b = b;
	}
	
	protected int compute()
	{
		return this.a+this.b;
	}
	

	

}
