package com.cel.app.cal.main;

import com.cel.app.cal.Calculator;
import com.cel.app.cal.operations.Addition;
import com.cel.app.cal.operations.Division;

public class Cal {
	
	public static void main(String []args)
	{
		try {
			Division d=new Division(10,0);
			
			System.out.println(d.compute());
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		Addition a=new Addition(10,5);
		System.out.println(a.compute());
		
		Calculator c=new Division(10,0);
		
		System.out.println(((Division)c).compute());
		
		c=new Addition(10,10);
		
		
		
		System.out.println(((Addition)c).compute());
		
	}

}
