package com.cel.app.cal.operations;

import com.cel.app.cal.Calculator;

public class Addition extends Calculator{
	
	public Addition(int a, int b) {
		super(a, b);
		
	}

	public int compute()
	{
		return super.getA()+super.getB();
	}

}
