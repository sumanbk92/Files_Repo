package com.cel.app.cal.operations;

import com.cel.app.cal.Calculator;

public class Division extends Calculator {

	public Division(int a, int b) {
		super(a, b);
		// TODO Auto-generated constructor stub
	}

	public int compute() 
	{
		try {
			return super.getA()/super.getB();
		} catch (Exception e) {
			throw e;
		}
		
		/*if(super.getB()!=0){
			return super.getA()/super.getB();
		}*/
	}

}
