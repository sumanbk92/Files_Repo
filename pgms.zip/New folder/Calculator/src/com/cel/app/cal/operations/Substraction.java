package com.cel.app.cal.operations;

import com.cel.app.cal.Calculator;

public class Substraction extends Calculator {
	
	protected Substraction(int a, int b) {
		super(a, b);
		// TODO Auto-generated constructor stub
	}

	protected int compute()
	{
		return super.getA()+super.getB();
	}

}
