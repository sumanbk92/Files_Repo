package com.thx.app.myapp.vehicles;

public class Car {
	private int mileage;
	private final int litres = 50;
	
	protected Car(int mileage){
		this.mileage = mileage;
	}
	
	protected int computeDistance(){
		return litres * mileage;
	}
	
	protected int getMileage(){
		return mileage;
	}
	
	protected void setMileage(int mileage){
		this.mileage = mileage;
	}
	
	protected int getLitres(){
		return litres;
	}
}


