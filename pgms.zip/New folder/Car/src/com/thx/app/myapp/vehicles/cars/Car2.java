package com.thx.app.myapp.vehicles.cars;

import com.thx.app.myapp.vehicles.Car;

public class Car2 extends Car{
	public Car2(int mileage){
		super(mileage);
	}
	
	public int computeDistance() {
		return ((getMileage() * getLitres())- 5);
	}
}
