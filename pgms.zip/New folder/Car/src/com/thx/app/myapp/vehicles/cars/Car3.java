package com.thx.app.myapp.vehicles.cars;

import com.thx.app.myapp.vehicles.Car;

public class Car3 extends Car{
	public Car3(int mileage) {
		super(mileage);
		// TODO Auto-generated constructor stub
	}
	
	public int computeDistance() {
		return super.computeDistance();
	}
	
	public int getMileage(){
		return super.getMileage();
	}
}
