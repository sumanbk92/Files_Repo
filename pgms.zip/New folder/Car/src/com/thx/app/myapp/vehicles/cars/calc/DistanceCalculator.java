package com.thx.app.myapp.vehicles.cars.calc;

import com.thx.app.myapp.vehicles.Car;
import com.thx.app.myapp.vehicles.cars.Car1;
import com.thx.app.myapp.vehicles.cars.Car2;
import com.thx.app.myapp.vehicles.cars.Car3;

public class DistanceCalculator {
	public static void main(String[] args) {
		Car1 c1 = new Car1(20);
		Car2 c2 = new Car2(17);
		Car3 c3 = new Car3(11);
		/*
		Car c;
		c = c3;*/
		System.out.println(c1.computeDistance());
		System.out.println(c2.computeDistance());
		System.out.println(c3.computeDistance());
		
		System.out.println(c3.getMileage());
	}
}
